class SearchController < ApplicationController
  def show
  end
end
