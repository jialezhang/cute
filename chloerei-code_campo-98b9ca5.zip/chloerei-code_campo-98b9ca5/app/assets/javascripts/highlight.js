//= require highlight_js/highlight
//= require highlight_js/languages/ruby
//= require highlight_js/languages/javascript
//= require highlight_js/languages/bash
//= require highlight_js/languages/xml
//= require highlight_js/languages/css

hljs.initHighlightingOnLoad();
