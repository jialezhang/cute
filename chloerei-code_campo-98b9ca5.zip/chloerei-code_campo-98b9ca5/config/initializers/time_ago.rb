Rails::Timeago.locales = AllowLocale
