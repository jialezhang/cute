FactoryGirl.define do
  factory :fragment do
  end
end
