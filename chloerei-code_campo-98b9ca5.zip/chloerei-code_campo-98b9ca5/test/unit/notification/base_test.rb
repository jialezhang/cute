require 'test_helper'

class Notification::BaseTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
