require 'test_helper'

class Notification::MentionTest < ActiveSupport::TestCase
end
