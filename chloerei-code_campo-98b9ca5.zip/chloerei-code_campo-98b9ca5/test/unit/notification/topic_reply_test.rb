require 'test_helper'

class Notification::TopicReplyTest < ActiveSupport::TestCase
end
