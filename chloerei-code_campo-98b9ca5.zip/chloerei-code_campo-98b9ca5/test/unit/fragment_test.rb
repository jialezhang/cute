require 'test_helper'

class FragmentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
